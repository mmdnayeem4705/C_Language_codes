#include <stdio.h>

int main(){ 
    int n = 12;
    for (int i=n; i ; i--){
        printf("%d\n",i); 
    }
        
    return 0;
}