#include<stdio.h>

int main(){
    int a; 
    scanf("%d", &a);
    printf("The value of a is %d", a);
    return 0;
}