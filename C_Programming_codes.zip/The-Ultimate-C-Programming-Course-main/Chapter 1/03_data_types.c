#include <stdio.h>

int main()
{
    // int a;
    // a = 1;
    int a = 1;

    // float b = 1.4;
    float b;
    b = 1.4;

    // char c = 'a';
    char c;
    c = 'a';

    printf("The value of a is %d\n", a);
    printf("The value of b is %f\n", b);
    printf("The value of c is %c\n", c);
}