#include<stdio.h>

int main(){
    int harry;
    int Harry; 
    int harry_good;
    return 0;
}