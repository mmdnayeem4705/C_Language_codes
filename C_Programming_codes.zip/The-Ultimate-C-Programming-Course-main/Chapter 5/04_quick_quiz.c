#include <stdio.h>
#include <math.h>

int main(){
    int a = 5;
    printf("The area of this square is %f\n", pow(a, 2));
    return 0;
}