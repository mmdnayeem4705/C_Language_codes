#include <stdio.h>

int main(){
    float a = 3.0 + 1 ;
    printf("The value of a is %f", a);
    return 0;
}