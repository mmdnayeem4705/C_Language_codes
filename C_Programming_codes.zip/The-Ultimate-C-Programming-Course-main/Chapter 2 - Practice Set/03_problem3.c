#include <stdio.h>

int main(){
    // int a = 2342354;
    int a = 3349895;
    printf("The value of a%97 is %d", a%97);
    return 0;
}